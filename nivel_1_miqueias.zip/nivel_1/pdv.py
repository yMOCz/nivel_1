from decimal import Decimal, ROUND_HALF_UP

IDADE_MINIMA = 65               # a partir dessa idade vale o desconto de idade
FATOR_IDADE = Decimal("0.80")   # 20% de desconto
LIMITE_VALOR = Decimal("100")   # o desconto por valor só vale ACIMA disso
FATOR_VALOR = Decimal("0.90")   # 10% de desconto extra
CENTAVO = Decimal("0.01")


def arredondar(valor):
    """Arredonda para 2 casas decimais (centavos), meio para cima."""
    return valor.quantize(CENTAVO, rounding=ROUND_HALF_UP)


def eh_numero(texto, inteiro):
    """Diz se o texto é um número: '-' opcional e, se não for inteiro, um ponto decimal."""
    if texto.startswith("-"):
        texto = texto[1:]
    if not inteiro and texto.count(".") == 1:
        texto = texto.replace(".", "")
    return texto.isdecimal()


def ler_numero(pergunta, inteiro=False):
    """Repete a pergunta até receber um número válido e não negativo."""
    while True:
        texto = input(pergunta).strip().replace(",", ".")
        if not eh_numero(texto, inteiro):
            print("Entrada inválida: digite apenas números.")
        else:
            numero = int(texto) if inteiro else Decimal(texto)
            if numero < 0:
                print("Aviso: números negativos não são aceitos. Tente novamente.")
            else:
                return numero


def calcular_compra(valor, idade):
    """Aplica as regras NA ORDEM (idade e depois valor).

    Devolve o valor final (arredondado) e a lista de descontos aplicados.
    """
    aplicados = []
    atual = valor

    if idade >= IDADE_MINIMA:
        atual = atual * FATOR_IDADE
        aplicados.append("idade (20%)")

    # Compara o valor que JÁ recebeu o desconto de idade, não o valor original.
    if atual > LIMITE_VALOR:
        atual = atual * FATOR_VALOR
        aplicados.append("valor (10%)")

    return arredondar(atual), aplicados


def mostrar_resumo(compras):
    """Percorre o histórico e mostra o resumo do dia."""
    total_bruto = Decimal("0")
    total_final = Decimal("0")

    for compra in compras:
        total_bruto += compra["bruto"]
        total_final += compra["final"]

    total_descontos = total_bruto - total_final

    print("\n" + "=" * 34)
    print("           RESUMO DO DIA")
    print("=" * 34)
    print(f"Compras registradas: {len(compras)}")
    print(f"Total bruto:         R$ {total_bruto:.2f}")
    print(f"Total de descontos:  R$ {total_descontos:.2f}")
    print(f"Total final:         R$ {total_final:.2f}")


def main():
    compras = []  # histórico do dia: um item para cada compra

    print("=== PDV com Descontos ===")

    while True:
        valor = ler_numero("\nValor da compra em R$ (0 para encerrar): ")
        if valor == 0:
            break

        idade = ler_numero("Idade do cliente: ", inteiro=True)

        valor = arredondar(valor)
        final, aplicados = calcular_compra(valor, idade)
        compras.append({"bruto": valor, "final": final})

        if aplicados:
            print("Descontos aplicados: " + " + ".join(aplicados))
        else:
            print("Descontos aplicados: nenhum")
        print(f"Valor final: R$ {final:.2f}")

    mostrar_resumo(compras)


if __name__ == "__main__":
    main()
